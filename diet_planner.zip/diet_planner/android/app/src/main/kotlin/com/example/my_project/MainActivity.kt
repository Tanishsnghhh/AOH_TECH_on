package com.mycompany.dietplanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
