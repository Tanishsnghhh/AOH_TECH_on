import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBTDuyrKvLGLiIZ4UeWkpnD--QO_8XmfpA",
            authDomain: "diet-planner-9jk2ym.firebaseapp.com",
            projectId: "diet-planner-9jk2ym",
            storageBucket: "diet-planner-9jk2ym.appspot.com",
            messagingSenderId: "304133298950",
            appId: "1:304133298950:web:89e073e7717aa1bc9e5c87"));
  } else {
    await Firebase.initializeApp();
  }
}
