// Export pages
export '/pages/registraionpage/registraionpage_widget.dart'
    show RegistraionpageWidget;
export '/chat_g_p_t_component/myprofile/myprofile_widget.dart'
    show MyprofileWidget;
export '/pages/patient_intakemain/patient_intakemain_widget.dart'
    show PatientIntakemainWidget;
export '/pages/weightaccuracy/weightaccuracy_widget.dart'
    show WeightaccuracyWidget;
export '/pages/selectfoodpref/selectfoodpref_widget.dart'
    show SelectfoodprefWidget;
export '/pages/gpt/gpt_widget.dart' show GptWidget;
